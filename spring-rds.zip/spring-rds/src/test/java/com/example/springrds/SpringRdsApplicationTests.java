package com.example.springrds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRdsApplicationTests {

	@Test
	void contextLoads() {
	}

}
