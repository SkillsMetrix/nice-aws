package com.pack.lambda;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Welcome {
	public String handler() {
		return "Welcome to Java Lambda";
	}
	public String handler2(String name) {
		return "Welcome  " + name;
	}

	public boolean handler3(boolean flag) {
		return !flag;
	}

	public int handleList(List<Integer> ints) {
		return ints.stream().mapToInt(Integer:: intValue).sum();
	}
	public Map<String, Integer>handlerMap(Map<String, Integer> inputMap){
		Map<String,Integer> updatedSalary=new HashMap<String, Integer>();
		inputMap.forEach((k,v) -> updatedSalary.put(k, v+500));
		return updatedSalary;
	}
	public List<Employee>handlePojo(List<Employee> emplist){
		return emplist.stream()
				.filter(emp -> emp.getName().startsWith("A"))
				.collect(Collectors.toList());
	}
	
}
