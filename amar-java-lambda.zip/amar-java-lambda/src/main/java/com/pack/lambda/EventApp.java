package com.pack.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class EventApp  implements RequestHandler<String  ,String>{

	@Override
	public String handleRequest(String input, Context context) {
		 context.getLogger().log("Welcome to Event based app " + input);
		return "Java Lambda " + input;
	}



 
}