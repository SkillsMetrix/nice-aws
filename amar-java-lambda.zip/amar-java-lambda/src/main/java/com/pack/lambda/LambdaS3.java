package com.pack.lambda;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.IOUtils;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

public class LambdaS3 implements RequestHandler<S3Event, String> {

	private static final String REGION = "us-east-1";
	AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withRegion(Regions.fromName(REGION))
			.withCredentials(new DefaultAWSCredentialsProviderChain()).build();

	@Override
	public String handleRequest(S3Event input, Context context) {
		String bucketName = input.getRecords().get(0).getS3().getBucket().getName();
		String fileName = input.getRecords().get(0).getS3().getObject().getKey();
		context.getLogger().log("Bucket Name  " + bucketName);
		context.getLogger().log("File Name  " + fileName);
		try {

			InputStream inputStream = s3Client.getObject(bucketName, fileName).getObjectContent();
			String content = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
			context.getLogger().log("File Content  " + content);
		} catch (Exception e) {
			return "Something went wrong" + e.getMessage();
		}
		return "Data Read Successfully....!";
	}

}
